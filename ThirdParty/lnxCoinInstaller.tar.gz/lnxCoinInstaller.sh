#/bin/bash  

export F77FLAGS="-Ofast"
export FFLAGS="-Ofast"
export CFLAGS="-Ofast"
export CXXFLAGS="-Ofast"
export LDFLAGS="-Ofast"

mkdir -p COIN
cd COIN

install_directory=$PWD"/dist"

git clone https://github.com/coin-or-tools/ThirdParty-Blas
cd ThirdParty-Blas
git checkout stable/1.4
./get.Blas
./configure --prefix=$install_directory --without-glpk --enable-static --disable-shared
make -j 4
make install

FILE=$install_directory"/lib/libcoinblas.la"
if [ ! -f "$FILE" ]; then
	echo "Erro ao instalar Blas"
    exit
fi

cd ..
git clone https://github.com/coin-or-tools/ThirdParty-Lapack
cd ThirdParty-Lapack
git checkout stable/1.6
./get.Lapack
./configure --prefix=$install_directory --without-glpk --enable-static --disable-shared
make -j 4
make install

FILE=$install_directory"/lib/libcoinlapack.la"
if [ ! -f "$FILE" ]; then
	echo "Erro ao instalar Lapack"
    exit
fi

cd ..
git clone https://github.com/coin-or/CoinUtils
cd CoinUtils
git checkout 754cd74ae395ff92aa4a6e990aa438d53aab2807
./configure --prefix=$install_directory --without-glpk --enable-static --disable-shared
make -j 4
make install

FILE=$install_directory"/lib/libCoinUtils.la"
if [ ! -f "$FILE" ]; then
	echo "Erro ao instalar CoinUtils"
    exit
fi

cd ..
git clone https://github.com/coin-or/Osi
cd Osi
git checkout 46ca62586ba5c956c1af88dfbdc74977c1c51b22
./configure --prefix=$install_directory --without-glpk --enable-static --disable-shared
make -j 4
make install

FILE=$install_directory"/lib/libOsi.la"
if [ ! -f "$FILE" ]; then
	echo "Erro ao instalar Osi"
    exit
fi

cd ..
git clone https://github.com/coin-or/Clp
cd Clp
git checkout cef2d02f52eb5d99f1d63144bf00ebd878295380
sed -i "s/small/small_/g" src/ClpSimplexOther.hpp
./configure --prefix=$install_directory --without-glpk --enable-static --disable-shared
make -j 4
make install

FILE=$install_directory"/lib/libClp.la"
if [ ! -f "$FILE" ]; then
	echo "Erro ao instalar Clp"
    exit
fi

cd ..
git clone https://github.com/coin-or/Cgl
cd Cgl
git checkout 2ad1324397d32e8c63e9c7680c64469d0db45391
sed -i "s/std::max/(std::max)/g" src/CglGMI/CglGMI.hpp
./configure --prefix=$install_directory --without-glpk --enable-static --disable-shared
make -j 4
make install

FILE=$install_directory"/lib/libCgl.la"
if [ ! -f "$FILE" ]; then
	echo "Erro ao instalar Cgl"
    exit
fi

cd ..
git clone https://github.com/coin-or/Cbc
cd Cbc
git checkout 83abbb8d4e7d54ae23b208ec4abcee35a5bbc78e
./configure --prefix=$install_directory --without-glpk --enable-static --disable-shared
make -j 4
make install

FILE=$install_directory"/lib/libCbc.la"
if [ ! -f "$FILE" ]; then
	echo "Erro ao instalar Cbc"
    exit
fi

